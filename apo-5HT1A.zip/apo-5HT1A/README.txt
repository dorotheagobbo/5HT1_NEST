For the apo-5HT1A receptor system, starting structure (5ht1a_rec_conf.gro) and topology files for the MD run are provided.
32 representative structures were extracted from the MD trajectory to initialise each walker. The protein coordinates are provided as pdb files.
Plumed input file to run MW-MetaD with A100 CV is also provided (plumed.dat).
Plumed input files to reweight the A100 metadynamics simulation are also provided (plumed_reweight_2D_microsw_5ht1a_rec.dat, plumed_reweight_microsw_5ht1a_rec.dat, COLVAR (for only 25ns of the trajectory).


